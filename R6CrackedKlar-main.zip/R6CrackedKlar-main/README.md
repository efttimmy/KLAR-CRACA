# R6CrackedKlar
I've cracked the code to klar really wasnt that hard all you gotta do is run the exe file and the menu should pop up under R34PS and have unlimited time 
